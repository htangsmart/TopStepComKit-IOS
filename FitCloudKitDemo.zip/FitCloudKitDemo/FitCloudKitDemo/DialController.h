//
//  DialController.h
//  FitCloudKitDemo
//
//  Created by Zhuanz on 2024/6/15.
//  Copyright © 2024 HetangSmart. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DialController : UITableViewController

@end

NS_ASSUME_NONNULL_END
