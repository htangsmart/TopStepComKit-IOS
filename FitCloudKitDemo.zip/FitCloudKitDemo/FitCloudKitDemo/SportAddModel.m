//
//  SportAddModel.m
//  FitCloudKitDemo
//
//  Created by Topstep on 2024/7/29.
//  Copyright © 2024 HetangSmart. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "SportAddModel.h"

@interface SportAddModel(){
    
}

@end

@implementation SportAddModel

@end
