//
//  HistoryDataController.h
//  FitCloudKitDemo
//
//  Created by Zhuanz密码0000 on 2024/6/6.
//  Copyright © 2024 HetangSmart. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HistoryDataController : UITableViewController

@end

NS_ASSUME_NONNULL_END
