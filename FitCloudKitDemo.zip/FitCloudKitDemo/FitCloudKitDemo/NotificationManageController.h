//
//  NotificationManageController.h
//  FitCloudKitDemo
//
//  Created by Topstep on 2024/6/15.
//  Copyright © 2024 HetangSmart. All rights reserved.
//

#ifndef NotificationManageController_h
#define NotificationManageController_h

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface NotificationManageController : UITableViewController

@property (weak, nonatomic) IBOutlet UITableView *mTableView;

@end

NS_ASSUME_NONNULL_END


#endif /* NotificationManageController_h */
