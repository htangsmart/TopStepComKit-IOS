//
//  SportAddController.h
//  FitCloudKitDemo
//
//  Created by Topstep on 2024/7/29.
//  Copyright © 2024 HetangSmart. All rights reserved.
//

#ifndef SportAddController_h
#define SportAddController_h

#import <UIKit/UIKit.h>

@interface SportAddController : UITableViewController

@property (weak, nonatomic) IBOutlet UITableView *mTableView;

@end


#endif /* SportAddController_h */
